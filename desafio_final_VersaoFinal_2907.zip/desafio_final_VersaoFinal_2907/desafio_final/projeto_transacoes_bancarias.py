# -----------------------
# depencies
# -----------------------
import json
import os
import uuid
import random
import sys

# -----------------------
# load settings
# -----------------------
sys.path.append('./data/')
from data import settings

# -----------------------
# SYSTEM functions 
# -----------------------
# não alterar nada das funções de system
def gera_transacao(categoria):
    return {
        "UUID": str(uuid.uuid4()),
        "valor": round(random.uniform(1.0, 1000.0), 2),  # Preço aleatório entre 1 e 1000
        "categoria": categoria
    }

def criar_transacoes(proporcao_categorias, num_transacoes=1,  categoria=None, seed=settings.seed):
    assert sum([proporcao_categorias[k] for k in proporcao_categorias])==1, '`proporcao_categorias` não soma 100%! Favor rever.'

    # garantir reprodutibilidade dos valores
    random.seed(seed)
    
    # Insere as transações para uma determinada categoria.
    if categoria:
        return [gera_transacao(categoria) for _ in range(0, num_transacoes)]
    
    # Calcula o número de transações por categoria com base na proporção
    numero_transacoes_por_categoria = {categoria: int(num_transacoes * proporcao) for categoria, proporcao in proporcao_categorias.items()}

    # Gera as transações
    transacoes = []
    for categoria, quantidade in numero_transacoes_por_categoria.items():
        for _ in range(quantidade):
            transacoes.append(gera_transacao(categoria))

    return transacoes

def salvar_json(transacoes, path2save, filename):
    # create path if not exist
    if not os.path.exists(path2save):
        os.makedirs(path2save)
    with open(os.path.join(path2save,filename), "w") as file:
        json.dump(transacoes, file, indent=4)
    print(f"Arquivo salvo em: {os.path.abspath(os.path.curdir)+'/'+path2save+'/'+filename}")

def criar_bd(num_transacoes:int = 10000, proporcao_categorias:list = settings.categorias_proporcao, path2save="./data", filename='transactions.json'):
    salvar_json(criar_transacoes(num_transacoes=num_transacoes,  proporcao_categorias=proporcao_categorias),
                path2save, filename
    )

def load_bd(filepath='./data/transactions.json'):
    with open(filepath, "r") as file:
        bd = json.load(file)
    return bd

#Limpa o terminal do python
def clear_Console():
    os.system('cls' if os.name == 'nt' else 'clear')

#esolhe a função conforme listagem padrão
def escolheCategoria():
    print("\nCategorias disponíveis:")
    for cat in settings.categorias_proporcao:
        print(f" - {cat}")
    categoria = input("Informe a categoria da transação: ").strip().lower()
    return categoria


def tela_inicial():

    #Menu principal do sistema
    print("Bem-vindo <teu nome inteiro aqui>!")
    print('conta: 0000001-0')
    print("\nEste programa permite gerenciar transações de sua conta pessoal.")
    print("\nEscolha uma das opções abaixo:")
    print("1. Visualizar relatórios")
    print("2. Cadastrar transações")
    print("3. Editar transações")
    print("4. Excluir transações")
    print("5. Consultar transação por ID")
    print("-" * 10)
    print("0. Sair")
    print('\n')

# -----------------------
# PROGRAM functions 
# -----------------------
# pode editar como quiser as funções abaixo! Somente não altere os nomes das funções.
# para alterar as funções abaixo, basta apagar o `pass` e preencher com as instruções.

def run():
    while True:
        try:
            tela_inicial()
            opcao = input("Digite a opção desejada: ").strip()

            if opcao == "1":
                visualizar_relatorios()
            elif opcao == "2":
                cadastrar_transacao()
            elif opcao == "3":          
                editar_transacao_por_ID()
            elif opcao == "4":
                excluir_transacao()
            elif opcao == "5":
                consultar_transacao_por_ID()
            elif opcao == "0":
                print("Saindo do programa. Até logo!")
                break
            else:
                print("Opção inválida. Tente novamente.")

        except Exception as e:
            print(f"Ocorreu um erro: {e}")
            input("Pressione ENTER para continuar...")

    tela_inicial()

def visualizar_relatorios():
    while True:
        #Limpa o console do python
        clear_Console()

        print("\n=== MENU DE RELATÓRIOS ===")
        print("1. Total de transações (geral)")
        print("2. Total de transações por categoria")
        print("3. Mostrar 5 maiores, menores ou médias transações (geral)")
        print("4. Mostrar 5 maiores, menores ou médias por categoria")
        print("5. Salvar relatório em .txt")
        print("0. Voltar ao menu principal")

        opcao = input("Escolha uma opção: ").strip()

        if opcao == "1":
            total = calcular_total_transacoes(bd)
            print(f"\nTotal de todas as transações: R$ {total:.2f}")
        elif opcao == "2":
            categorias = list(settings.categorias_proporcao.keys())
            for cat in categorias:
                total = calcular_total_transacoes(bd, cat)
                print(f"  - {cat.capitalize()}: R$ {total:.2f}")
        elif opcao == "3":
            while True:
                # Limpa o console do python
                clear_Console()

                print("=== 5 Transações (GERAL) ===")
                print("Escolha o tipo de análise:")
                print("1. Maiores transações")
                print("2. Menores transações")
                print("3. Transações mais próximas da média")
                print("0. Voltar")

                subopcao = input("Tipo: ").strip()

                if subopcao == "1":
                    mostrar_m5_transacoes(bd, tipo='max')
                elif subopcao == "2":
                    mostrar_m5_transacoes(bd, tipo='min')
                elif subopcao == "3":
                    mostrar_m5_transacoes(bd, tipo='median')
                elif subopcao == "0":
                    break
                else:
                    print("Opção inválida.")

                input("\nPressione ENTER para continuar...")
        elif opcao == "4":
            while True:
                #Limpa o terminal do python
                clear_Console()

                print("=== 5 Transações POR CATEGORIA ===")
                print("Categorias disponíveis:")
                for cat in settings.categorias_proporcao:
                    print(f" - {cat}")
                print("Digite 'voltar' para retornar ao menu.")

                categoria = input("\nCategoria: ").strip().lower()
                if categoria == 'voltar':
                    break
                if categoria not in settings.categorias_proporcao:
                    print("Categoria inválida.")
                    input("Pressione ENTER para continuar...")
                    continue

                print("\nEscolha o tipo de análise:")
                print("1. Maiores transações")
                print("2. Menores transações")
                print("3. Transações mais próximas da média")
                tipo = input("Tipo: ").strip()

                if tipo == "1":
                    mostrar_m5_transacoes(bd, tipo='max', categoria=categoria)
                elif tipo == "2":
                    mostrar_m5_transacoes(bd, tipo='min', categoria=categoria)
                elif tipo == "3":
                    mostrar_m5_transacoes(bd, tipo='median', categoria=categoria)
                else:
                    print("Tipo inválido.")

                input("\nPressione ENTER para continuar...")
        elif opcao == "5":
            salvar_relatorio(bd)
        elif opcao == "0":
            break
        else:
            print("Opção inválida.")

        input("\nPressione ENTER para continuar...")

def salvar_relatorio(bd):
    caminho = input("Digite o nome do arquivo (ex: relatorio.txt): ").strip()
    try:
        with open(caminho, 'w', encoding='utf-8') as f:
            f.write("RELATÓRIO DE TRANSAÇÕES\n")
            f.write("========================\n\n")
            f.write(f"Total geral: R$ {calcular_total_transacoes(bd):.2f}\n\n")
            f.write("Total por categoria:\n")
            for cat in settings.categorias_proporcao:
                f.write(f"  - {cat.capitalize()}: R$ {calcular_total_transacoes(bd, cat):.2f}\n")
        print(f"\nRelatório salvo como '{caminho}'")
    except Exception as e:
        print(f"Erro ao salvar relatório: {e}")

def calcular_total_transacoes(bd, categoria=None):
    if categoria:
        return sum(float(t["valor"]) for t in bd if t["categoria"] == categoria)
    return sum(float(t["valor"]) for t in bd)

def mostrar_m5_transacoes(bd, tipo='max', categoria=None):
    if categoria:
        dados = [t for t in bd if t["categoria"] == categoria]
    else:
        dados = bd[:]

    if not dados:
        print("Nenhuma transação encontrada.")
        return
    # Ordena a listagem pelo valor
    valores = sorted(dados, key=lambda x: x["valor"])

    if tipo == 'max':
        #retorna os 5 maiores valores
        selecionadas = valores[-5:]
    elif tipo == 'min':
        # retorna os 5 menores valores
        selecionadas = valores[:5]
    elif tipo == 'median':
        media = calcular_media(dados)
        selecionadas = sorted(dados, key=lambda x: abs(x["valor"] - media))[:5]
    else:
        print("Tipo inválido. Use 'max', 'min' ou 'median'.")
        return

    print(f"\nTransações ({'categoria: ' + categoria if categoria else 'geral'}) | Tipo: {tipo}")
    for t in selecionadas:
        print(f"  ID: {t['UUID']} | R$ {t['valor']:.2f} | Categoria: {t['categoria']}")

def calcular_media(bd):
    if not bd:
        return 0
    return sum(float(t["valor"]) for t in bd) / len(bd)

def consultar_transacao_por_ID():
    while True:
        #Limpa o terminal do python
        clear_Console()

        print("=== CONSULTAR TRANSAÇÃO POR ID ===")
        print("Digite o UUID da transação ou 'voltar' para retornar ao menu.")

        entrada = input("UUID: ").strip()

        if entrada.lower() == 'voltar':
            break

        transacao = next((t for t in bd if t['UUID'] == entrada), None)

        if transacao:
            print("\nTransação encontrada:")
            print(f"  ID        : {transacao['UUID']}")
            print(f"  Valor     : R$ {transacao['valor']:.2f}")
            print(f"  Categoria : {transacao['categoria']}")
        else:
            print("Nenhuma transação encontrada com esse UUID.")

        input("\nPressione ENTER para continuar...")

def cadastrar_transacao():
    global bd
    while True:
        #Limpa o terminal do python
        clear_Console()

        print("=== CADASTRAR NOVA TRANSAÇÃO ===")
        print("Digite 'voltar' a qualquer momento para retornar ao menu.")


        valor_input = input("Informe o valor da transação: ").strip()

        #Trata o valor digitado obrigando ser um float
        if valor_input.lower() == 'voltar':
            break
        try:
            valor = float(valor_input)
            if valor <= 0:
                print("O valor deve ser positivo.")
                input("Pressione ENTER para continuar...")
                continue
        except ValueError:
            print("Valor inválido. Use ponto como separador decimal (ex: 123.45).")
            input("Pressione ENTER para continuar...")
            continue

        #retorna a categoria escolhida
        categoria = escolheCategoria()

        if categoria == 'voltar':
            break
        if categoria not in settings.categorias_proporcao:
            print("Categoria inválida.")
            input("Pressione ENTER para continuar...")
            continue

        nova_transacao = {
            "UUID": str(uuid.uuid4()),
            "valor": round(valor, 2),
            "categoria": categoria
        }

        bd.append(nova_transacao)
        salvar_json(bd, './data', 'transactions.json')

        print("\nTransação cadastrada com sucesso!")
        print(f"  ID        : {nova_transacao['UUID']}")
        print(f"  Valor     : R$ {nova_transacao['valor']:.2f}")
        print(f"  Categoria : {nova_transacao['categoria']}")

        continuar = input("\nDeseja cadastrar outra transação? (s/n): ").strip().lower()
        if continuar != 's':
            break

def editar_transacao_por_ID():
    global bd

    while True:
        #Limpa o terminal do python
        clear_Console()

        print("=== EDITAR TRANSAÇÃO ===")
        print("Digite o UUID da transação que deseja editar ou 'voltar' para retornar ao menu.")

        uuid_input = input("UUID: ").strip()
        if uuid_input.lower() == 'voltar':
            break
        #Busca a transação no banco de dados através pelo UUID digitado
        transacao = next((t for t in bd if t['UUID'] == uuid_input), None)

        #Tratamento para voltar ao menu caso a transação não seja encontrada.
        if not transacao:
            print("Transação não encontrada.")
            input("Pressione ENTER para tentar novamente...")
            continue

        #Existe na tela a tranasão que será editada.
        print(f"\nTransação atual:")
        print(f"  ID        : {transacao['UUID']}")
        print(f"  Valor     : R$ {transacao['valor']:.2f}")
        print(f"  Categoria : {transacao['categoria']}")

        while True:
            novo_valor = input("Informe o novo valor: ").strip()

            # Trata o valor digitado obrigando ser um float
            if novo_valor.lower() == 'voltar':
                break
            try:
                novo_valor = float(novo_valor)
                if novo_valor <= 0:
                    print("O valor deve ser positivo.")
                    input("Pressione ENTER para continuar...")
                    continue
                break
            except ValueError:
                print("Valor inválido. Use ponto como separador decimal (ex: 123.45).")
                input("Pressione ENTER para continuar...")
                continue

        transacao["valor"] = novo_valor

        # Trata até uma categoria válida seja selecionada.
        while True:
            categoria = escolheCategoria()
            if categoria == 'voltar':
                break
            if categoria not in settings.categorias_proporcao:
                print("Categoria inválida.")
                input("Pressione ENTER para continuar...")
                continue
            else:
                break

        transacao["categoria"] = categoria

        salvar_json(bd, './data', 'transactions.json')
        print("Categoria atualizada com sucesso!")

    input("\nPressione ENTER para continuar...")

def excluir_transacao():
    global bd
    while True:
        # Limpa o terminal do python
        clear_Console()

        print("=== EXCLUIR TRANSAÇÃO ===")
        print("Digite o UUID da transação que deseja excluir ou 'voltar' para retornar ao menu.")

        uuid_input = input("UUID: ").strip()
        if uuid_input.lower() == 'voltar':
            break

        transacao = next((t for t in bd if t['UUID'] == uuid_input), None)

        if not transacao:
            print("Transação não encontrada.")
            input("Pressione ENTER para tentar novamente...")
            continue

        print("\nTransação encontrada:")
        print(f"  ID        : {transacao['UUID']}")
        print(f"  Valor     : R$ {transacao['valor']:.2f}")
        print(f"  Categoria : {transacao['categoria']}")

        confirmar = input("\nTem certeza que deseja excluir esta transação? (s/n): ").strip().lower()
        if confirmar == 's':
            bd.remove(transacao)
            salvar_json(bd, './data', 'transactions.json')
            print("Transação excluída com sucesso!")
        else:
            print("Exclusão cancelada.")

        input("\nPressione ENTER para continuar...")

if __name__ == "__main__":
    print(os.path.abspath('.'))
    if not os.path.exists('./data/transactions.json'):
        criar_bd()
    bd = load_bd()

    # Limpa o terminal do python
    clear_Console()
    run()



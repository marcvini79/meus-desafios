
#settings:   --- por favor não altere!
categorias_proporcao = {
        "casa": 0.15,
        "lazer": 0.1,
        "viagens": 0.05,
        "investimentos": 0.2,
        "transferencias": 0.1,
        "saude": 0.1,
        "alimentacao": 0.3
    }

seed = 11